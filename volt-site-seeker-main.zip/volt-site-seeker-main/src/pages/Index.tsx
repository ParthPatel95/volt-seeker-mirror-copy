
import Landing from "@/pages/Landing";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const Index = () => {
  return <Landing />;
};

export default Index;
