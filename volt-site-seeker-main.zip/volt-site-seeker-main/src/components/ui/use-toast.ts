
// Re-export from the hooks directory to maintain compatibility
export { useToast, toast } from "@/hooks/use-toast";
