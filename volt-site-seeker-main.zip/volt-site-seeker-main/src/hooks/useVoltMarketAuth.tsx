// Consolidated auth hook - all imports should use this single source
export { 
  useVoltMarketAuth, 
  type VoltMarketProfile 
} from '@/contexts/VoltMarketAuthContext';